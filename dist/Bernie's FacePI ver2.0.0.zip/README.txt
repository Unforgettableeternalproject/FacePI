# FacePI
Trying to do a face identification program. Also F.

2022/1/4 Completed FacePI ver 1.0.

2022/1/6 Completed FacePI ver 2.0 (With custom windows).

To be added:
    Nothing for now.

>在資料夾中找到Bernie's FacePI便可執行。

原始碼: https://github.com/Unforgettableeternalproject/FacePI